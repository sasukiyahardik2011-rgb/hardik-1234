# PANDA GAME - GitHub APK Ready

આ ફોલ્ડરની બધી files GitHub repository ના root માં upload કરો.

GitHub Actions આપમેળે `gradle assembleDebug` ચલાવીને APK બનાવશે.

APK મેળવવા: **Actions → Build PANDA GAME APK → latest successful run → Artifacts → PANDA-GAME-APK**.
