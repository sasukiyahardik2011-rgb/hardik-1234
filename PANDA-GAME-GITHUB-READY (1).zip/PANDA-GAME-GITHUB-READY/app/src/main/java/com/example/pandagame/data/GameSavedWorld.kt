package com.example.pandagame.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_worlds")
data class GameSavedWorld(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val seed: Long,
    val biomeName: String,
    val blockCount: Int,
    val modifiedBlockCount: Int,
    val playerX: Float,
    val playerY: Float,
    val playerZ: Float,
    val playerYaw: Float,
    val playerPitch: Float,
    val lastPlayedTime: Long = System.currentTimeMillis(),
    val playTimeMinutes: Int = 0,
    val serializedBlocks: String
)
