package com.example.pandagame.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [GameSavedWorld::class], version = 1, exportSchema = false)
abstract class PandaDatabase : RoomDatabase() {
    abstract fun savedWorldDao(): SavedWorldDao

    companion object {
        @Volatile
        private var INSTANCE: PandaDatabase? = null

        fun getDatabase(context: Context): PandaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PandaDatabase::class.java,
                    "panda_game_database"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
