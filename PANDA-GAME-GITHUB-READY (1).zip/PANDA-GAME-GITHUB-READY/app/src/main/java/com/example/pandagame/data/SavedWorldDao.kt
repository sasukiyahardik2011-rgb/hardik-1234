package com.example.pandagame.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedWorldDao {
    @Query("SELECT * FROM saved_worlds ORDER BY lastPlayedTime DESC")
    fun getAllWorlds(): Flow<List<GameSavedWorld>>

    @Query("SELECT * FROM saved_worlds WHERE id = :id LIMIT 1")
    suspend fun getWorldById(id: Long): GameSavedWorld?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorld(world: GameSavedWorld): Long

    @Update
    suspend fun updateWorld(world: GameSavedWorld)

    @Delete
    suspend fun deleteWorld(world: GameSavedWorld)

    @Query("DELETE FROM saved_worlds WHERE id = :id")
    suspend fun deleteById(id: Long)
}
