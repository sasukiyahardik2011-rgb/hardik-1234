package com.example.pandagame.data

import com.example.pandagame.engine.WorldGenerator
import com.example.pandagame.model.VoxelWorld
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class WorldRepository(private val dao: SavedWorldDao) {

    val allSavedWorlds: Flow<List<GameSavedWorld>> = dao.getAllWorlds()

    suspend fun loadWorldById(id: Long): Pair<VoxelWorld, GameSavedWorld?> = withContext(Dispatchers.IO) {
        val saved = dao.getWorldById(id)
        if (saved != null) {
            val world = VoxelWorld(
                sizeX = 32, sizeY = 24, sizeZ = 32,
                seed = saved.seed,
                worldName = saved.name,
                biomeName = saved.biomeName
            )
            world.deserialize(saved.serializedBlocks)
            Pair(world, saved)
        } else {
            val defaultWorld = createNewWorld("Panda Bamboo Valley", "Bamboo Forest", 12345L)
            Pair(defaultWorld, null)
        }
    }

    suspend fun saveWorld(
        world: VoxelWorld,
        existingId: Long?,
        playerX: Float,
        playerY: Float,
        playerZ: Float,
        playerYaw: Float,
        playerPitch: Float,
        playTimeMinutes: Int
    ): Long = withContext(Dispatchers.IO) {
        val serialized = world.serialize()
        val totalBlocks = world.countTotalSolidBlocks()

        val entity = GameSavedWorld(
            id = existingId ?: 0L,
            name = world.worldName,
            seed = world.seed,
            biomeName = world.biomeName,
            blockCount = totalBlocks,
            modifiedBlockCount = world.modifiedBlockCount,
            playerX = playerX,
            playerY = playerY,
            playerZ = playerZ,
            playerYaw = playerYaw,
            playerPitch = playerPitch,
            lastPlayedTime = System.currentTimeMillis(),
            playTimeMinutes = playTimeMinutes,
            serializedBlocks = serialized
        )

        dao.insertWorld(entity)
    }

    suspend fun deleteWorld(world: GameSavedWorld) = withContext(Dispatchers.IO) {
        dao.deleteWorld(world)
    }

    suspend fun createNewWorld(
        name: String,
        biomeName: String,
        seed: Long = System.currentTimeMillis()
    ): VoxelWorld = withContext(Dispatchers.Default) {
        val world = VoxelWorld(
            sizeX = 32,
            sizeY = 24,
            sizeZ = 32,
            seed = seed,
            worldName = name,
            biomeName = biomeName
        )
        WorldGenerator.generateWorld(world, biomeName)
        world
    }

    suspend fun ensureDefaultWorlds() = withContext(Dispatchers.IO) {
        // Create initial starter world if database is empty
        val defaultWorld = createNewWorld("Panda Bamboo Valley", "Bamboo Forest", 777L)
        val entity = GameSavedWorld(
            name = "Panda Bamboo Valley",
            seed = 777L,
            biomeName = "Bamboo Forest",
            blockCount = defaultWorld.countTotalSolidBlocks(),
            modifiedBlockCount = 0,
            playerX = 16f,
            playerY = 12f,
            playerZ = 16f,
            playerYaw = 0f,
            playerPitch = -15f,
            lastPlayedTime = System.currentTimeMillis(),
            playTimeMinutes = 10,
            serializedBlocks = defaultWorld.serialize()
        )
        dao.insertWorld(entity)

        val sakuraWorld = createNewWorld("Sakura Garden Sanctuary", "Sakura Valley", 888L)
        val entity2 = GameSavedWorld(
            name = "Sakura Garden Sanctuary",
            seed = 888L,
            biomeName = "Sakura Valley",
            blockCount = sakuraWorld.countTotalSolidBlocks(),
            modifiedBlockCount = 0,
            playerX = 16f,
            playerY = 12f,
            playerZ = 16f,
            playerYaw = 45f,
            playerPitch = -10f,
            lastPlayedTime = System.currentTimeMillis() - 86400000,
            playTimeMinutes = 25,
            serializedBlocks = sakuraWorld.serialize()
        )
        dao.insertWorld(entity2)
    }
}
