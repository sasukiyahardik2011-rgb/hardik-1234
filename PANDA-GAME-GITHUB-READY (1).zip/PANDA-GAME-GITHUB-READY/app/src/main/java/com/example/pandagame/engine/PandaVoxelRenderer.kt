package com.example.pandagame.engine

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.pandagame.model.BlockFace
import com.example.pandagame.model.BlockPos
import com.example.pandagame.model.BlockType
import com.example.pandagame.model.PandaCompanion
import com.example.pandagame.model.PlayerState
import com.example.pandagame.model.Vector3
import com.example.pandagame.model.VoxelWorld
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class PandaVoxelRenderer {

    // Internal data structures for depth-sorted polygon rendering
    private class RenderFace(
        val p1: Offset,
        val p2: Offset,
        val p3: Offset,
        val p4: Offset,
        val depth: Float,
        val color: Color,
        val isTargeted: Boolean = false,
        val isDecorated: Boolean = false,
        val blockType: BlockType = BlockType.AIR
    )

    private val facePool = ArrayList<RenderFace>(2048)

    fun render(
        drawScope: DrawScope,
        world: VoxelWorld,
        player: PlayerState,
        panda: PandaCompanion,
        timeOfDay: Float, // 0.0 to 1.0 (0.25 = noon, 0.75 = midnight)
        renderDistance: Int = 12
    ) {
        val width = drawScope.size.width
        val height = drawScope.size.height
        val aspect = width / height
        val fov = 1.1f // ~65 deg fov

        val camPos = player.getCameraPosition()
        val yawRad = Math.toRadians(player.yaw.toDouble()).toFloat()
        val pitchRad = Math.toRadians(player.pitch.toDouble()).toFloat()

        val cosYaw = cos(yawRad)
        val sinYaw = sin(yawRad)
        val cosPitch = cos(pitchRad)
        val sinPitch = sin(pitchRad)

        // Forward, Right, Up camera basis vectors
        val camFwd = Vector3(sinYaw * cosPitch, -sinPitch, cosYaw * cosPitch).normalized()
        val camRight = Vector3(cosYaw, 0f, -sinYaw).normalized()
        val camUp = camRight.cross(camFwd).normalized()

        // 1. Draw dynamic sky background
        drawSky(drawScope, timeOfDay, player.pitch)

        facePool.clear()

        val playerBlockX = camPos.x.toInt()
        val playerBlockY = camPos.y.toInt()
        val playerBlockZ = camPos.z.toInt()

        val minX = (playerBlockX - renderDistance).coerceAtLeast(0)
        val maxX = (playerBlockX + renderDistance).coerceAtMost(world.sizeX - 1)
        val minY = (playerBlockY - 8).coerceAtLeast(0)
        val maxY = (playerBlockY + 8).coerceAtMost(world.sizeY - 1)
        val minZ = (playerBlockZ - renderDistance).coerceAtLeast(0)
        val maxZ = (playerBlockZ + renderDistance).coerceAtMost(world.sizeZ - 1)

        val targetPos = player.targetRaycast?.hitBlockPos

        // 2. Iterate voxel blocks and extract visible outer faces
        for (x in minX..maxX) {
            for (y in minY..maxY) {
                for (z in minZ..maxZ) {
                    val block = world.getBlock(x, y, z)
                    if (block == BlockType.AIR) continue

                    val isTargeted = (targetPos != null && targetPos.x == x && targetPos.y == y && targetPos.z == z)

                    // Check all 6 faces: only render if neighbor is transparent/air
                    // TOP (+Y)
                    if (shouldRenderFace(world, x, y + 1, z, block)) {
                        addCubeFace(
                            x, y, z, BlockFace.TOP, block,
                            camPos, camFwd, camRight, camUp, width, height, aspect, fov,
                            isTargeted, lightFactor = 1.0f
                        )
                    }
                    // BOTTOM (-Y)
                    if (shouldRenderFace(world, x, y - 1, z, block)) {
                        addCubeFace(
                            x, y, z, BlockFace.BOTTOM, block,
                            camPos, camFwd, camRight, camUp, width, height, aspect, fov,
                            isTargeted, lightFactor = 0.55f
                        )
                    }
                    // NORTH (+Z)
                    if (shouldRenderFace(world, x, y, z + 1, block)) {
                        addCubeFace(
                            x, y, z, BlockFace.NORTH, block,
                            camPos, camFwd, camRight, camUp, width, height, aspect, fov,
                            isTargeted, lightFactor = 0.78f
                        )
                    }
                    // SOUTH (-Z)
                    if (shouldRenderFace(world, x, y, z - 1, block)) {
                        addCubeFace(
                            x, y, z, BlockFace.SOUTH, block,
                            camPos, camFwd, camRight, camUp, width, height, aspect, fov,
                            isTargeted, lightFactor = 0.82f
                        )
                    }
                    // EAST (+X)
                    if (shouldRenderFace(world, x + 1, y, z, block)) {
                        addCubeFace(
                            x, y, z, BlockFace.EAST, block,
                            camPos, camFwd, camRight, camUp, width, height, aspect, fov,
                            isTargeted, lightFactor = 0.88f
                        )
                    }
                    // WEST (-X)
                    if (shouldRenderFace(world, x - 1, y, z, block)) {
                        addCubeFace(
                            x, y, z, BlockFace.WEST, block,
                            camPos, camFwd, camRight, camUp, width, height, aspect, fov,
                            isTargeted, lightFactor = 0.72f
                        )
                    }
                }
            }
        }

        // 3. Render Cute 3D Panda Model
        render3DPanda(panda, camPos, camFwd, camRight, camUp, width, height, aspect, fov)

        // 4. Sort visible faces back-to-front (Painter's Algorithm)
        facePool.sortByDescending { it.depth }

        // 5. Rasterize faces
        val path = Path()
        val outlineColor = Color(0x99FFFFFF)
        val targetBorderColor = Color(0xFFFFD54F)

        for (face in facePool) {
            path.reset()
            path.moveTo(face.p1.x, face.p1.y)
            path.lineTo(face.p2.x, face.p2.y)
            path.lineTo(face.p3.x, face.p3.y)
            path.lineTo(face.p4.x, face.p4.y)
            path.close()

            // Fill face
            drawScope.drawPath(path, face.color, style = Fill)

            // Subtle voxel grid edge line
            if (face.depth < 10f) {
                drawScope.drawPath(
                    path,
                    if (face.isTargeted) targetBorderColor else outlineColor.copy(alpha = (1.0f - (face.depth / 10f)) * 0.15f),
                    style = Stroke(width = if (face.isTargeted) 3.5f else 1.0f)
                )
            }

            // Decorative Panda block face stencil (Lanterns / Totems)
            if (face.isDecorated) {
                val cx = (face.p1.x + face.p2.x + face.p3.x + face.p4.x) / 4f
                val cy = (face.p1.y + face.p2.y + face.p3.y + face.p4.y) / 4f
                val r = (abs(face.p2.x - face.p1.x) + abs(face.p3.y - face.p1.y)) * 0.12f
                if (r > 3f) {
                    drawScope.drawCircle(
                        color = if (face.blockType == BlockType.PANDA_LANTERN) Color(0xAAFFF9C4) else Color(0x99263238),
                        radius = r,
                        center = Offset(cx, cy)
                    )
                }
            }
        }

        // 6. Draw Crosshair in screen center
        val centerX = width / 2f
        val centerY = height / 2f
        val crosshairSize = 14f
        val crosshairThickness = 2.5f

        drawScope.drawLine(
            color = Color(0xEEFFFFFF),
            start = Offset(centerX - crosshairSize, centerY),
            end = Offset(centerX + crosshairSize, centerY),
            strokeWidth = crosshairThickness
        )
        drawScope.drawLine(
            color = Color(0xEEFFFFFF),
            start = Offset(centerX, centerY - crosshairSize),
            end = Offset(centerX, centerY + crosshairSize),
            strokeWidth = crosshairThickness
        )
        // Center dot
        drawScope.drawCircle(
            color = if (player.targetRaycast != null) Color(0xFFFFEB3B) else Color(0xCCFFFFFF),
            radius = 2.5f,
            center = Offset(centerX, centerY)
        )
    }

    private fun shouldRenderFace(world: VoxelWorld, nx: Int, ny: Int, nz: Int, currentBlock: BlockType): Boolean {
        if (!world.isValid(nx, ny, nz)) return true
        val neighbor = world.getBlock(nx, ny, nz)
        if (neighbor == BlockType.AIR) return true
        if (neighbor.isTransparent && neighbor != currentBlock) return true
        return false
    }

    private fun addCubeFace(
        bx: Int, by: Int, bz: Int,
        face: BlockFace,
        block: BlockType,
        camPos: Vector3, camFwd: Vector3, camRight: Vector3, camUp: Vector3,
        width: Float, height: Float, aspect: Float, fov: Float,
        isTargeted: Boolean,
        lightFactor: Float
    ) {
        // Face corners in 3D world space (cube 1x1x1)
        val fx = bx.toFloat()
        val fy = by.toFloat()
        val fz = bz.toFloat()

        val v1: Vector3
        val v2: Vector3
        val v3: Vector3
        val v4: Vector3

        when (face) {
            BlockFace.TOP -> {
                v1 = Vector3(fx, fy + 1f, fz)
                v2 = Vector3(fx + 1f, fy + 1f, fz)
                v3 = Vector3(fx + 1f, fy + 1f, fz + 1f)
                v4 = Vector3(fx, fy + 1f, fz + 1f)
            }
            BlockFace.BOTTOM -> {
                v1 = Vector3(fx, fy, fz + 1f)
                v2 = Vector3(fx + 1f, fy, fz + 1f)
                v3 = Vector3(fx + 1f, fy, fz)
                v4 = Vector3(fx, fy, fz)
            }
            BlockFace.NORTH -> {
                v1 = Vector3(fx + 1f, fy, fz + 1f)
                v2 = Vector3(fx, fy, fz + 1f)
                v3 = Vector3(fx, fy + 1f, fz + 1f)
                v4 = Vector3(fx + 1f, fy + 1f, fz + 1f)
            }
            BlockFace.SOUTH -> {
                v1 = Vector3(fx, fy, fz)
                v2 = Vector3(fx + 1f, fy, fz)
                v3 = Vector3(fx + 1f, fy + 1f, fz)
                v4 = Vector3(fx, fy + 1f, fz)
            }
            BlockFace.EAST -> {
                v1 = Vector3(fx + 1f, fy, fz)
                v2 = Vector3(fx + 1f, fy, fz + 1f)
                v3 = Vector3(fx + 1f, fy + 1f, fz + 1f)
                v4 = Vector3(fx + 1f, fy + 1f, fz)
            }
            BlockFace.WEST -> {
                v1 = Vector3(fx, fy, fz + 1f)
                v2 = Vector3(fx, fy, fz)
                v3 = Vector3(fx, fy + 1f, fz)
                v4 = Vector3(fx, fy + 1f, fz + 1f)
            }
        }

        // Backface culling: vector from camera to face center dot face normal
        val faceCenter = (v1 + v2 + v3 + v4) * 0.25f
        val camToFace = faceCenter - camPos
        if (camToFace.dot(face.normal) >= 0f) return // Back-facing

        // Project 4 vertices to screen
        val p1 = project(v1, camPos, camFwd, camRight, camUp, width, height, aspect, fov) ?: return
        val p2 = project(v2, camPos, camFwd, camRight, camUp, width, height, aspect, fov) ?: return
        val p3 = project(v3, camPos, camFwd, camRight, camUp, width, height, aspect, fov) ?: return
        val p4 = project(v4, camPos, camFwd, camRight, camUp, width, height, aspect, fov) ?: return

        val depth = camToFace.length()
        val baseColor = when (face) {
            BlockFace.TOP -> block.topColor
            BlockFace.BOTTOM -> block.bottomColor
            else -> block.sideColor
        }

        // Apply shade / lighting
        val shadedColor = applyLight(baseColor, lightFactor, block.isLightEmitter)

        val isDecorated = (block == BlockType.PANDA_LANTERN || block == BlockType.PANDA_TOTEM)

        facePool.add(
            RenderFace(
                p1 = p1,
                p2 = p2,
                p3 = p3,
                p4 = p4,
                depth = depth,
                color = shadedColor,
                isTargeted = isTargeted,
                isDecorated = isDecorated,
                blockType = block
            )
        )
    }

    private fun render3DPanda(
        panda: PandaCompanion,
        camPos: Vector3, camFwd: Vector3, camRight: Vector3, camUp: Vector3,
        width: Float, height: Float, aspect: Float, fov: Float
    ) {
        val px = panda.position.x
        val py = panda.position.y
        val pz = panda.position.z

        val animWalk = sin(panda.animTime * 6f) * 0.15f
        val animChew = if (panda.isEating) abs(sin(panda.animTime * 8f)) * 0.08f else 0f

        // Cute blocky panda parts:
        // 1. Body (white block)
        addBox(
            px - 0.35f, py, pz - 0.35f,
            0.7f, 0.65f, 0.7f,
            Color(0xFFF5F5F5),
            camPos, camFwd, camRight, camUp, width, height, aspect, fov
        )

        // 2. Head (white block) + chew bobbing
        val headY = py + 0.6f + animChew
        addBox(
            px - 0.3f, headY, pz - 0.3f,
            0.6f, 0.5f, 0.6f,
            Color(0xFFFAFAFA),
            camPos, camFwd, camRight, camUp, width, height, aspect, fov
        )

        // 3. Black Ears (two small dark cubes)
        addBox(
            px - 0.38f, headY + 0.45f, pz - 0.1f,
            0.2f, 0.2f, 0.2f,
            Color(0xFF212121),
            camPos, camFwd, camRight, camUp, width, height, aspect, fov
        )
        addBox(
            px + 0.18f, headY + 0.45f, pz - 0.1f,
            0.2f, 0.2f, 0.2f,
            Color(0xFF212121),
            camPos, camFwd, camRight, camUp, width, height, aspect, fov
        )

        // 4. Black Eye Patches
        addBox(
            px - 0.26f, headY + 0.2f, pz + 0.28f,
            0.16f, 0.16f, 0.08f,
            Color(0xFF1E1E1E),
            camPos, camFwd, camRight, camUp, width, height, aspect, fov
        )
        addBox(
            px + 0.10f, headY + 0.2f, pz + 0.28f,
            0.16f, 0.16f, 0.08f,
            Color(0xFF1E1E1E),
            camPos, camFwd, camRight, camUp, width, height, aspect, fov
        )

        // 5. Cute Bamboo Snack in hand if eating
        if (panda.isEating) {
            addBox(
                px - 0.05f, py + 0.35f, pz + 0.38f,
                0.1f, 0.45f, 0.1f,
                Color(0xFF66BB6A),
                camPos, camFwd, camRight, camUp, width, height, aspect, fov
            )
        }

        // 6. Black Legs/Paws with walk animation
        addBox(
            px - 0.35f, py - 0.15f + animWalk, pz - 0.25f,
            0.25f, 0.3f, 0.25f,
            Color(0xFF212121),
            camPos, camFwd, camRight, camUp, width, height, aspect, fov
        )
        addBox(
            px + 0.10f, py - 0.15f - animWalk, pz - 0.25f,
            0.25f, 0.3f, 0.25f,
            Color(0xFF212121),
            camPos, camFwd, camRight, camUp, width, height, aspect, fov
        )
    }

    private fun addBox(
        x: Float, y: Float, z: Float,
        w: Float, h: Float, d: Float,
        color: Color,
        camPos: Vector3, camFwd: Vector3, camRight: Vector3, camUp: Vector3,
        width: Float, height: Float, aspect: Float, fov: Float
    ) {
        val faces = listOf(
            // Top
            listOf(Vector3(x, y + h, z), Vector3(x + w, y + h, z), Vector3(x + w, y + h, z + d), Vector3(x, y + h, z + d)) to 1.0f,
            // North
            listOf(Vector3(x + w, y, z + d), Vector3(x, y, z + d), Vector3(x, y + h, z + d), Vector3(x + w, y + h, z + d)) to 0.8f,
            // South
            listOf(Vector3(x, y, z), Vector3(x + w, y, z), Vector3(x + w, y + h, z), Vector3(x, y + h, z)) to 0.8f,
            // East
            listOf(Vector3(x + w, y, z), Vector3(x + w, y, z + d), Vector3(x + w, y + h, z + d), Vector3(x + w, y + h, z)) to 0.85f,
            // West
            listOf(Vector3(x, y, z + d), Vector3(x, y, z), Vector3(x, y + h, z), Vector3(x, y + h, z + d)) to 0.75f
        )

        for ((quad, shade) in faces) {
            val p1 = project(quad[0], camPos, camFwd, camRight, camUp, width, height, aspect, fov) ?: continue
            val p2 = project(quad[1], camPos, camFwd, camRight, camUp, width, height, aspect, fov) ?: continue
            val p3 = project(quad[2], camPos, camFwd, camRight, camUp, width, height, aspect, fov) ?: continue
            val p4 = project(quad[3], camPos, camFwd, camRight, camUp, width, height, aspect, fov) ?: continue

            val center = (quad[0] + quad[1] + quad[2] + quad[3]) * 0.25f
            val depth = (center - camPos).length()

            facePool.add(
                RenderFace(
                    p1 = p1, p2 = p2, p3 = p3, p4 = p4,
                    depth = depth,
                    color = applyLight(color, shade, false)
                )
            )
        }
    }

    private fun project(
        vertex: Vector3,
        camPos: Vector3,
        camFwd: Vector3,
        camRight: Vector3,
        camUp: Vector3,
        screenWidth: Float,
        screenHeight: Float,
        aspect: Float,
        fov: Float
    ): Offset? {
        val rel = vertex - camPos
        // Transform to camera local space
        val viewZ = rel.dot(camFwd)
        if (viewZ < 0.2f) return null // Near plane clipping

        val viewX = rel.dot(camRight)
        val viewY = rel.dot(camUp)

        val projX = (viewX / (viewZ * fov * aspect))
        val projY = (viewY / (viewZ * fov))

        val screenX = (projX * 0.5f + 0.5f) * screenWidth
        val screenY = (-projY * 0.5f + 0.5f) * screenHeight

        return Offset(screenX, screenY)
    }

    private fun applyLight(color: Color, factor: Float, isEmitter: Boolean): Color {
        if (isEmitter) return color
        return Color(
            red = (color.red * factor).coerceIn(0f, 1f),
            green = (color.green * factor).coerceIn(0f, 1f),
            blue = (color.blue * factor).coerceIn(0f, 1f),
            alpha = color.alpha
        )
    }

    private fun drawSky(drawScope: DrawScope, timeOfDay: Float, pitchDeg: Float) {
        val width = drawScope.size.width
        val height = drawScope.size.height

        // Dynamic Sky Gradient based on Time of Day
        val (topSky, horizonSky) = when {
            timeOfDay in 0.15f..0.35f -> {
                // Noon / Sunny
                Color(0xFF4FC3F7) to Color(0xFFE1F5FE)
            }
            timeOfDay in 0.35f..0.50f -> {
                // Sunset
                Color(0xFF5C6BC0) to Color(0xFFFF7043)
            }
            timeOfDay in 0.50f..0.85f -> {
                // Night / Twinkling
                Color(0xFF0D1B2A) to Color(0xFF1B263B)
            }
            else -> {
                // Dawn / Morning
                Color(0xFF7986CB) to Color(0xFFFFAB91)
            }
        }

        // Draw sky gradient background
        drawScope.drawRect(
            color = topSky,
            topLeft = Offset(0f, 0f),
            size = Size(width, height * 0.6f)
        )
        drawScope.drawRect(
            color = horizonSky,
            topLeft = Offset(0f, height * 0.5f),
            size = Size(width, height * 0.5f)
        )

        // Draw cute Voxel Sun or Moon
        val sunSize = 36f
        val sunX = width * 0.75f
        val sunY = height * 0.18f + (pitchDeg * 2.5f)

        if (timeOfDay in 0.05f..0.55f) {
            // Sun (Golden square voxel sun)
            drawScope.drawRect(
                color = Color(0xFFFFEB3B),
                topLeft = Offset(sunX - sunSize / 2, sunY - sunSize / 2),
                size = Size(sunSize, sunSize)
            )
            drawScope.drawRect(
                color = Color(0x66FFF59D),
                topLeft = Offset(sunX - sunSize * 0.8f, sunY - sunSize * 0.8f),
                size = Size(sunSize * 1.6f, sunSize * 1.6f)
            )
        } else {
            // Moon & Stars
            drawScope.drawRect(
                color = Color(0xFFFFF9C4),
                topLeft = Offset(sunX - sunSize / 2, sunY - sunSize / 2),
                size = Size(sunSize * 0.85f, sunSize * 0.85f)
            )
        }
    }
}
