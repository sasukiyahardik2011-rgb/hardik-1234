package com.example.pandagame.engine

import com.example.pandagame.model.BlockType
import com.example.pandagame.model.VoxelWorld
import java.util.Random
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

object WorldGenerator {

    fun generateWorld(world: VoxelWorld, biomeType: String = "Bamboo Forest") {
        val rand = Random(world.seed)

        when (biomeType) {
            "Bamboo Forest" -> generateBambooForest(world, rand)
            "Sakura Valley" -> generateSakuraValley(world, rand)
            "Panda Sanctuary" -> generatePandaSanctuary(world, rand)
            "Zen Flatlands" -> generateZenFlatlands(world, rand)
            else -> generateBambooForest(world, rand)
        }
    }

    private fun generateBambooForest(world: VoxelWorld, rand: Random) {
        val baseWaterHeight = 4

        // 1. Terrain elevation pass
        for (x in 0 until world.sizeX) {
            for (z in 0 until world.sizeZ) {
                // Perlin-like simple sine wave rolling hills
                val nx = x.toDouble() * 0.18 + (world.seed % 100)
                val nz = z.toDouble() * 0.18 + (world.seed % 50)
                val hill = sin(nx) * cos(nz) * 2.5 + sin(nx * 0.5) * 1.5 + 7.0
                val height = hill.toInt().coerceIn(3, world.sizeY - 8)

                for (y in 0..height) {
                    if (y == 0) {
                        world.setBlockRaw(x, y, z, BlockType.PANDA_STONE.id)
                    } else if (y < height - 2) {
                        world.setBlockRaw(x, y, z, BlockType.PANDA_STONE.id)
                    } else if (y < height) {
                        world.setBlockRaw(x, y, z, BlockType.PANDA_SOIL.id)
                    } else {
                        // Top block
                        if (y <= baseWaterHeight) {
                            world.setBlockRaw(x, y, z, BlockType.ZEN_SAND.id)
                        } else {
                            world.setBlockRaw(x, y, z, BlockType.PANDA_GRASS.id)
                        }
                    }
                }

                // Fill water in low valleys
                for (y in (height + 1)..baseWaterHeight) {
                    world.setBlockRaw(x, y, z, BlockType.CRYSTAL_WATER.id)
                }
            }
        }

        // 2. Bamboo clusters & flora
        for (x in 2 until world.sizeX - 2) {
            for (z in 2 until world.sizeZ - 2) {
                val surfaceY = findSurfaceY(world, x, z)
                if (surfaceY > baseWaterHeight && world.getBlock(x, surfaceY, z) == BlockType.PANDA_GRASS) {
                    val roll = rand.nextFloat()
                    if (roll < 0.12f) {
                        // Grow bamboo stalk
                        val height = rand.nextInt(4) + 4
                        for (h in 1..height) {
                            if (surfaceY + h < world.sizeY - 2) {
                                world.setBlockRaw(x, surfaceY + h, z, BlockType.BAMBOO_STALK.id)
                            }
                        }
                        // Leaves on top
                        val topY = (surfaceY + height).coerceAtMost(world.sizeY - 2)
                        world.setBlockRaw(x, topY, z, BlockType.BAMBOO_LEAVES.id)
                        if (rand.nextBoolean()) world.setBlockRaw(x + 1, topY, z, BlockType.BAMBOO_LEAVES.id)
                        if (rand.nextBoolean()) world.setBlockRaw(x - 1, topY, z, BlockType.BAMBOO_LEAVES.id)
                        if (rand.nextBoolean()) world.setBlockRaw(x, topY, z + 1, BlockType.BAMBOO_LEAVES.id)
                    } else if (roll < 0.15f) {
                        // Golden Bamboo
                        val topY = (surfaceY + 1).coerceAtMost(world.sizeY - 2)
                        world.setBlockRaw(x, topY, z, BlockType.GOLDEN_BAMBOO.id)
                    }
                }
            }
        }

        // 3. Build a cute Panda Pavilion & Lanterns in the center
        val cx = world.sizeX / 2
        val cz = world.sizeZ / 2
        val cy = findSurfaceY(world, cx, cz) + 1

        buildPavilion(world, cx, cy, cz)

        // 4. Place a cute carved panda totem near the spawn
        world.setBlock(cx + 4, cy, cz + 2, BlockType.PANDA_TOTEM)
        world.setBlock(cx + 4, cy + 1, cz + 2, BlockType.PANDA_LANTERN)
    }

    private fun generateSakuraValley(world: VoxelWorld, rand: Random) {
        for (x in 0 until world.sizeX) {
            for (z in 0 until world.sizeZ) {
                val nx = x.toDouble() * 0.15
                val nz = z.toDouble() * 0.15
                val height = (sin(nx) * 2.0 + cos(nz) * 2.0 + 6.0).toInt().coerceIn(3, world.sizeY - 8)

                for (y in 0..height) {
                    if (y < height - 2) world.setBlockRaw(x, y, z, BlockType.PANDA_STONE.id)
                    else if (y < height) world.setBlockRaw(x, y, z, BlockType.PANDA_SOIL.id)
                    else world.setBlockRaw(x, y, z, BlockType.PANDA_GRASS.id)
                }
            }
        }

        // Add Sakura trees
        for (x in 3 until world.sizeX - 3 step 5) {
            for (z in 3 until world.sizeZ - 3 step 5) {
                val sy = findSurfaceY(world, x, z)
                if (rand.nextFloat() < 0.7f && sy > 3 && sy < world.sizeY - 6) {
                    buildCherryTree(world, x, sy + 1, z, rand)
                }
            }
        }
    }

    private fun generatePandaSanctuary(world: VoxelWorld, rand: Random) {
        // High stone terraces with bamboo and panda statues
        for (x in 0 until world.sizeX) {
            for (z in 0 until world.sizeZ) {
                val distFromCenter = sqrt(((x - world.sizeX / 2) * (x - world.sizeX / 2) + (z - world.sizeZ / 2) * (z - world.sizeZ / 2)).toDouble())
                val height = ((12.0 - distFromCenter * 0.5) + sin(x.toDouble() * 0.3) * 1.5).toInt().coerceIn(3, world.sizeY - 6)

                for (y in 0..height) {
                    if (y < height - 1) world.setBlockRaw(x, y, z, BlockType.PANDA_STONE.id)
                    else world.setBlockRaw(x, y, z, BlockType.MOSS_BRICK.id)
                }
            }
        }

        // Central Panda Shrine
        val cx = world.sizeX / 2
        val cz = world.sizeZ / 2
        val cy = findSurfaceY(world, cx, cz) + 1

        buildPandaStatue(world, cx, cy, cz)
    }

    private fun generateZenFlatlands(world: VoxelWorld, rand: Random) {
        // Smooth flat building platform
        val floorY = 5
        for (x in 0 until world.sizeX) {
            for (z in 0 until world.sizeZ) {
                for (y in 0 until floorY) {
                    world.setBlockRaw(x, y, z, BlockType.PANDA_STONE.id)
                }
                world.setBlockRaw(x, floorY, z, BlockType.PANDA_GRASS.id)
            }
        }

        // Zen stone ring in center
        val cx = world.sizeX / 2
        val cz = world.sizeZ / 2
        for (dx in -3..3) {
            for (dz in -3..3) {
                if (dx * dx + dz * dz <= 10) {
                    world.setBlock(cx + dx, floorY, cz + dz, BlockType.ZEN_SAND)
                }
            }
        }
        world.setBlock(cx, floorY + 1, cz, BlockType.PANDA_TOTEM)
        world.setBlock(cx, floorY + 2, cz, BlockType.PANDA_LANTERN)
    }

    private fun buildPavilion(world: VoxelWorld, cx: Int, cy: Int, cz: Int) {
        // 4 stone pillar corners
        for (dx in listOf(-2, 2)) {
            for (dz in listOf(-2, 2)) {
                for (dy in 0..3) {
                    world.setBlock(cx + dx, cy + dy, cz + dz, BlockType.CHERRY_WOOD)
                }
                world.setBlock(cx + dx, cy + 4, cz + dz, BlockType.PANDA_LANTERN)
            }
        }
        // Roof
        for (dx in -3..3) {
            for (dz in -3..3) {
                world.setBlock(cx + dx, cy + 4, cz + dz, BlockType.BAMBOO_PLANKS)
            }
        }
    }

    private fun buildCherryTree(world: VoxelWorld, x: Int, y: Int, z: Int, rand: Random) {
        val trunkHeight = rand.nextInt(2) + 3
        for (h in 0 until trunkHeight) {
            world.setBlock(x, y + h, z, BlockType.CHERRY_WOOD)
        }
        val top = y + trunkHeight
        for (dx in -1..1) {
            for (dz in -1..1) {
                for (dy in 0..1) {
                    if (world.getBlock(x + dx, top + dy, z + dz) == BlockType.AIR) {
                        world.setBlock(x + dx, top + dy, z + dz, BlockType.CHERRY_BLOSSOM)
                    }
                }
            }
        }
    }

    private fun buildPandaStatue(world: VoxelWorld, x: Int, y: Int, z: Int) {
        // Cute 3D blocky panda statue in world
        // Body (White fur)
        for (dx in -1..1) {
            for (dz in -1..1) {
                for (dy in 0..1) {
                    world.setBlock(x + dx, y + dy, z + dz, BlockType.PANDA_FUR_WHITE)
                }
            }
        }
        // Black arms / shoulders
        world.setBlock(x - 2, y + 1, z, BlockType.PANDA_FUR_BLACK)
        world.setBlock(x + 2, y + 1, z, BlockType.PANDA_FUR_BLACK)
        world.setBlock(x - 1, y, z - 1, BlockType.PANDA_FUR_BLACK)
        world.setBlock(x + 1, y, z - 1, BlockType.PANDA_FUR_BLACK)

        // Head (White)
        for (dx in -1..1) {
            for (dz in -1..1) {
                world.setBlock(x + dx, y + 2, z + dz, BlockType.PANDA_FUR_WHITE)
            }
        }
        // Black ears
        world.setBlock(x - 1, y + 3, z, BlockType.PANDA_FUR_BLACK)
        world.setBlock(x + 1, y + 3, z, BlockType.PANDA_FUR_BLACK)
        // Black eye patches
        world.setBlock(x - 1, y + 2, z + 1, BlockType.PANDA_FUR_BLACK)
        world.setBlock(x + 1, y + 2, z + 1, BlockType.PANDA_FUR_BLACK)
    }

    private fun findSurfaceY(world: VoxelWorld, x: Int, z: Int): Int {
        for (y in (world.sizeY - 1) downTo 0) {
            val b = world.getBlock(x, y, z)
            if (b != BlockType.AIR) return y
        }
        return 0
    }
}
