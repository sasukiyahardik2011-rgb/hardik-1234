package com.example.pandagame.model

import android.util.Base64
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class VoxelWorld(
    val sizeX: Int = 32,
    val sizeY: Int = 24,
    val sizeZ: Int = 32,
    val seed: Long = System.currentTimeMillis(),
    var worldName: String = "Panda Bamboo Valley",
    var biomeName: String = "Bamboo Forest"
) {
    private val blocks = ByteArray(sizeX * sizeY * sizeZ)
    var isDirty: Boolean = false
        private set

    var modifiedBlockCount: Int = 0

    init {
        // Initializes empty
    }

    private fun index(x: Int, y: Int, z: Int): Int {
        return (y * sizeZ + z) * sizeX + x
    }

    fun isValid(x: Int, y: Int, z: Int): Boolean {
        return x in 0 until sizeX && y in 0 until sizeY && z in 0 until sizeZ
    }

    fun getBlock(x: Int, y: Int, z: Int): BlockType {
        if (!isValid(x, y, z)) return BlockType.AIR
        val id = blocks[index(x, y, z)]
        return BlockType.fromId(id)
    }

    fun getBlockId(x: Int, y: Int, z: Int): Byte {
        if (!isValid(x, y, z)) return 0
        return blocks[index(x, y, z)]
    }

    fun setBlock(x: Int, y: Int, z: Int, type: BlockType): Boolean {
        if (!isValid(x, y, z)) return false
        val idx = index(x, y, z)
        val oldId = blocks[idx]
        if (oldId != type.id) {
            blocks[idx] = type.id
            isDirty = true
            modifiedBlockCount++
            return true
        }
        return false
    }

    fun setBlockRaw(x: Int, y: Int, z: Int, typeId: Byte) {
        if (isValid(x, y, z)) {
            blocks[index(x, y, z)] = typeId
        }
    }

    fun countTotalSolidBlocks(): Int {
        var count = 0
        for (b in blocks) {
            if (b != 0.toByte()) count++
        }
        return count
    }

    fun serialize(): String {
        return Base64.encodeToString(blocks, Base64.NO_WRAP)
    }

    fun deserialize(base64Data: String) {
        try {
            val decoded = Base64.decode(base64Data, Base64.NO_WRAP)
            val copyLen = min(decoded.size, blocks.size)
            System.arraycopy(decoded, 0, blocks, 0, copyLen)
            isDirty = false
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Fast 3D Voxel Raycaster (Amanatides & Woo DDA Algorithm)
     * Casts a ray from origin in direction up to maxDistance.
     */
    fun raycast(origin: Vector3, direction: Vector3, maxDistance: Float = 7.5f): RaycastResult? {
        val dir = direction.normalized()
        var currentX = floor(origin.x).toInt()
        var currentY = floor(origin.y).toInt()
        var currentZ = floor(origin.z).toInt()

        val stepX = if (dir.x > 0) 1 else if (dir.x < 0) -1 else 0
        val stepY = if (dir.y > 0) 1 else if (dir.y < 0) -1 else 0
        val stepZ = if (dir.z > 0) 1 else if (dir.z < 0) -1 else 0

        val tDeltaX = if (stepX != 0) 1f / kotlin.math.abs(dir.x) else Float.MAX_VALUE
        val tDeltaY = if (stepY != 0) 1f / kotlin.math.abs(dir.y) else Float.MAX_VALUE
        val tDeltaZ = if (stepZ != 0) 1f / kotlin.math.abs(dir.z) else Float.MAX_VALUE

        var tMaxX = if (stepX > 0) ((currentX + 1) - origin.x) * tDeltaX else (origin.x - currentX) * tDeltaX
        var tMaxY = if (stepY > 0) ((currentY + 1) - origin.y) * tDeltaY else (origin.y - currentY) * tDeltaY
        var tMaxZ = if (stepZ > 0) ((currentZ + 1) - origin.z) * tDeltaZ else (origin.z - currentZ) * tDeltaZ

        var lastFace = BlockFace.TOP
        var distTraveled = 0f

        while (distTraveled <= maxDistance) {
            if (isValid(currentX, currentY, currentZ)) {
                val block = getBlock(currentX, currentY, currentZ)
                if (block != BlockType.AIR && block != BlockType.CRYSTAL_WATER) {
                    val hitPos = BlockPos(currentX, currentY, currentZ)
                    val placePos = hitPos + lastFace
                    return RaycastResult(
                        hitBlockPos = hitPos,
                        hitFace = lastFace,
                        placeBlockPos = placePos,
                        hitDistance = distTraveled
                    )
                }
            }

            if (tMaxX < tMaxY) {
                if (tMaxX < tMaxZ) {
                    distTraveled = tMaxX
                    tMaxX += tDeltaX
                    currentX += stepX
                    lastFace = if (stepX > 0) BlockFace.WEST else BlockFace.EAST
                } else {
                    distTraveled = tMaxZ
                    tMaxZ += tDeltaZ
                    currentZ += stepZ
                    lastFace = if (stepZ > 0) BlockFace.SOUTH else BlockFace.NORTH
                }
            } else {
                if (tMaxY < tMaxZ) {
                    distTraveled = tMaxY
                    tMaxY += tDeltaY
                    currentY += stepY
                    lastFace = if (stepY > 0) BlockFace.BOTTOM else BlockFace.TOP
                } else {
                    distTraveled = tMaxZ
                    tMaxZ += tDeltaZ
                    currentZ += stepZ
                    lastFace = if (stepZ > 0) BlockFace.SOUTH else BlockFace.NORTH
                }
            }
        }

        return null
    }
}
