package com.example.pandagame.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.pandagame.data.GameSavedWorld
import com.example.pandagame.data.PandaDatabase
import com.example.pandagame.data.WorldRepository
import com.example.pandagame.engine.PandaAudio
import com.example.pandagame.engine.WorldGenerator
import com.example.pandagame.model.BlockFace
import com.example.pandagame.model.BlockPos
import com.example.pandagame.model.BlockType
import com.example.pandagame.model.PandaCompanion
import com.example.pandagame.model.PlayerState
import com.example.pandagame.model.Vector3
import com.example.pandagame.model.VoxelWorld
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

enum class GameScreen {
    TITLE_SPLASH,
    MAIN_MENU,
    LOADING,
    IN_GAME,
    SAVED_WORLDS,
    NEW_WORLD,
    GUIDE,
    SETTINGS
}

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: WorldRepository
    val audio: PandaAudio = PandaAudio(application)

    private val _currentScreen = MutableStateFlow(GameScreen.TITLE_SPLASH)
    val currentScreen: StateFlow<GameScreen> = _currentScreen.asStateFlow()

    private val _voxelWorld = MutableStateFlow(VoxelWorld())
    val voxelWorld: StateFlow<VoxelWorld> = _voxelWorld.asStateFlow()

    private val _playerState = MutableStateFlow(PlayerState())
    val playerState: StateFlow<PlayerState> = _playerState.asStateFlow()

    private val _pandaCompanion = MutableStateFlow(PandaCompanion())
    val pandaCompanion: StateFlow<PandaCompanion> = _pandaCompanion.asStateFlow()

    private val _timeOfDay = MutableStateFlow(0.25f) // Noon default
    val timeOfDay: StateFlow<Float> = _timeOfDay.asStateFlow()

    private val _savedWorlds = MutableStateFlow<List<GameSavedWorld>>(emptyList())
    val savedWorlds: StateFlow<List<GameSavedWorld>> = _savedWorlds.asStateFlow()

    private val _currentWorldId = MutableStateFlow<Long?>(null)
    val currentWorldId: StateFlow<Long?> = _currentWorldId.asStateFlow()

    private val _loadingProgress = MutableStateFlow(0f)
    val loadingProgress: StateFlow<Float> = _loadingProgress.asStateFlow()

    private val _loadingMessage = MutableStateFlow("PANDA GAME is loading...")
    val loadingMessage: StateFlow<String> = _loadingMessage.asStateFlow()

    private val _isPaused = MutableStateFlow(false)
    val isPaused: StateFlow<Boolean> = _isPaused.asStateFlow()

    private val _isInventoryOpen = MutableStateFlow(false)
    val isInventoryOpen: StateFlow<Boolean> = _isInventoryOpen.asStateFlow()

    private val _gameToast = MutableStateFlow<String?>(null)
    val gameToast: StateFlow<String?> = _gameToast.asStateFlow()

    // Settings
    val lookSensitivity = MutableStateFlow(0.45f)
    val renderDistance = MutableStateFlow(12)
    val isDayNightCycleEnabled = MutableStateFlow(true)

    private var gameLoopRunning = false
    private var sessionPlayTimeSeconds = 0

    init {
        val db = PandaDatabase.getDatabase(application)
        repository = WorldRepository(db.savedWorldDao())

        viewModelScope.launch {
            repository.allSavedWorlds.collect { worlds ->
                _savedWorlds.value = worlds
                if (worlds.isEmpty()) {
                    repository.ensureDefaultWorlds()
                }
            }
        }

        startGameLoop()
    }

    private fun startGameLoop() {
        if (gameLoopRunning) return
        gameLoopRunning = true

        viewModelScope.launch(Dispatchers.Default) {
            var lastTime = System.currentTimeMillis()
            while (true) {
                val now = System.currentTimeMillis()
                val delta = ((now - lastTime) / 1000f).coerceIn(0.001f, 0.1f)
                lastTime = now

                if (_currentScreen.value == GameScreen.IN_GAME && !_isPaused.value) {
                    sessionPlayTimeSeconds++
                    updatePhysics(delta)
                    _pandaCompanion.value.update(delta, _playerState.value.position, _voxelWorld.value)

                    if (isDayNightCycleEnabled.value) {
                        _timeOfDay.value = (_timeOfDay.value + (delta * 0.005f)) % 1.0f
                    }
                }
                delay(33) // ~30-40fps physics tick
            }
        }
    }

    fun navigateTo(screen: GameScreen) {
        audio.playButtonClick()
        _currentScreen.value = screen
    }

    fun startNewGame(worldName: String, biome: String, seed: Long = System.currentTimeMillis()) {
        viewModelScope.launch {
            _currentScreen.value = GameScreen.LOADING
            _loadingProgress.value = 0.1f
            _loadingMessage.value = "PANDA GAME: Generating $biome terrain..."
            delay(250)

            val world = repository.createNewWorld(worldName, biome, seed)
            _loadingProgress.value = 0.6f
            _loadingMessage.value = "PANDA GAME: Planting Bamboo & Placing Panda Totems..."
            delay(250)

            _voxelWorld.value = world
            _currentWorldId.value = null
            _playerState.value = PlayerState(
                position = Vector3(16f, 13f, 16f),
                yaw = 0f,
                pitch = -12f
            )
            _pandaCompanion.value = PandaCompanion(position = Vector3(18f, 12f, 18f))

            _loadingProgress.value = 1.0f
            _loadingMessage.value = "PANDA GAME Ready!"
            delay(200)

            _isPaused.value = false
            _currentScreen.value = GameScreen.IN_GAME
            showToast("Welcome to PANDA GAME! 🎋")
        }
    }

    fun loadSavedWorld(savedWorld: GameSavedWorld) {
        viewModelScope.launch {
            _currentScreen.value = GameScreen.LOADING
            _loadingProgress.value = 0.2f
            _loadingMessage.value = "PANDA GAME: Loading ${savedWorld.name}..."
            delay(200)

            val (world, entity) = repository.loadWorldById(savedWorld.id)
            _loadingProgress.value = 0.8f
            _loadingMessage.value = "PANDA GAME: Restoring Voxel Blocks..."
            delay(200)

            _voxelWorld.value = world
            _currentWorldId.value = entity?.id
            _playerState.value = PlayerState(
                position = Vector3(entity?.playerX ?: 16f, entity?.playerY ?: 13f, entity?.playerZ ?: 16f),
                yaw = entity?.playerYaw ?: 0f,
                pitch = entity?.playerPitch ?: -10f
            )
            _pandaCompanion.value = PandaCompanion(
                position = Vector3((entity?.playerX ?: 16f) + 2f, (entity?.playerY ?: 13f), (entity?.playerZ ?: 16f) + 2f)
            )

            _loadingProgress.value = 1.0f
            delay(150)

            _isPaused.value = false
            _currentScreen.value = GameScreen.IN_GAME
            showToast("Loaded ${savedWorld.name} in PANDA GAME! 🐾")
        }
    }

    fun saveCurrentWorld(customName: String? = null) {
        viewModelScope.launch {
            val world = _voxelWorld.value
            if (customName != null && customName.isNotBlank()) {
                world.worldName = customName
            }
            val player = _playerState.value
            val id = repository.saveWorld(
                world = world,
                existingId = _currentWorldId.value,
                playerX = player.position.x,
                playerY = player.position.y,
                playerZ = player.position.z,
                playerYaw = player.yaw,
                playerPitch = player.pitch,
                playTimeMinutes = (sessionPlayTimeSeconds / 60) + 1
            )
            _currentWorldId.value = id
            audio.playButtonClick()
            showToast("World saved to PANDA GAME Saves! 💾")
        }
    }

    fun deleteSavedWorld(savedWorld: GameSavedWorld) {
        viewModelScope.launch {
            repository.deleteWorld(savedWorld)
            audio.playButtonClick()
            showToast("Deleted ${savedWorld.name} from PANDA GAME")
        }
    }

    fun pauseGame() {
        audio.playButtonClick()
        _isPaused.value = true
    }

    fun resumeGame() {
        audio.playButtonClick()
        _isPaused.value = false
    }

    fun toggleInventory() {
        audio.playButtonClick()
        _isInventoryOpen.value = !_isInventoryOpen.value
    }

    fun selectHotbarSlot(blockType: BlockType) {
        audio.playButtonClick()
        _playerState.value = _playerState.value.copy(selectedBlock = blockType)
    }

    fun togglePOV() {
        audio.playButtonClick()
        _playerState.value = _playerState.value.copy(isThirdPerson = !_playerState.value.isThirdPerson)
        showToast(if (_playerState.value.isThirdPerson) "Panda 3rd Person View 🐼" else "First Person View 👁️")
    }

    fun toggleFlight() {
        audio.playButtonClick()
        _playerState.value = _playerState.value.copy(isFlying = !_playerState.value.isFlying)
        showToast(if (_playerState.value.isFlying) "Creative Flying Enabled 🪽" else "Walking Mode 🐾")
    }

    fun toggleTimeOfDay() {
        audio.playButtonClick()
        val newTime = (_timeOfDay.value + 0.25f) % 1.0f
        _timeOfDay.value = newTime
        val timeLabel = when {
            newTime in 0.15f..0.35f -> "Daytime ☀️"
            newTime in 0.35f..0.55f -> "Sunset 🌅"
            newTime in 0.55f..0.85f -> "Starry Night 🌙"
            else -> "Dawn 🌄"
        }
        showToast("Time shifted to $timeLabel")
    }

    fun rotateCamera(deltaYaw: Float, deltaPitch: Float) {
        val sens = lookSensitivity.value
        val player = _playerState.value
        val newYaw = (player.yaw + deltaYaw * sens) % 360f
        val newPitch = (player.pitch - deltaPitch * sens).coerceIn(-85f, 85f)
        _playerState.value = player.copy(yaw = newYaw, pitch = newPitch)

        // Update target raycast
        updateRaycast()
    }

    fun movePlayer(moveX: Float, moveZ: Float, moveY: Float = 0f) {
        val player = _playerState.value
        val yawRad = Math.toRadians(player.yaw.toDouble()).toFloat()
        val cosYaw = cos(yawRad)
        val sinYaw = sin(yawRad)

        // Strafe and forward vectors
        val forward = Vector3(sinYaw, 0f, cosYaw)
        val right = Vector3(cosYaw, 0f, -sinYaw)

        val speed = if (player.isFlying) 0.35f else 0.22f
        val deltaMove = (forward * moveZ + right * moveX + Vector3(0f, moveY, 0f)) * speed

        val newPos = player.position + deltaMove
        val clampedPos = Vector3(
            newPos.x.coerceIn(1f, (_voxelWorld.value.sizeX - 2).toFloat()),
            newPos.y.coerceIn(1f, (_voxelWorld.value.sizeY - 2).toFloat()),
            newPos.z.coerceIn(1f, (_voxelWorld.value.sizeZ - 2).toFloat())
        )

        _playerState.value = player.copy(position = clampedPos)
        updateRaycast()
    }

    fun jumpOrFlyUp() {
        val player = _playerState.value
        if (player.isFlying) {
            movePlayer(0f, 0f, 1.2f)
        } else {
            // Jump
            _playerState.value = player.copy(position = player.position + Vector3(0f, 1.0f, 0f))
            audio.playButtonClick()
        }
    }

    fun flyDown() {
        if (_playerState.value.isFlying) {
            movePlayer(0f, 0f, -1.2f)
        }
    }

    fun breakTargetBlock() {
        val hit = _playerState.value.targetRaycast ?: return
        val pos = hit.hitBlockPos
        val success = _voxelWorld.value.setBlock(pos.x, pos.y, pos.z, BlockType.AIR)
        if (success) {
            audio.playBlockBreak()
            updateRaycast()
        }
    }

    fun placeBlock() {
        val hit = _playerState.value.targetRaycast ?: return
        val pos = hit.placeBlockPos
        val selected = _playerState.value.selectedBlock
        if (selected == BlockType.AIR) return

        if (_voxelWorld.value.isValid(pos.x, pos.y, pos.z)) {
            val success = _voxelWorld.value.setBlock(pos.x, pos.y, pos.z, selected)
            if (success) {
                audio.playBlockPlace()
                updateRaycast()
            }
        }
    }

    fun feedPanda() {
        _pandaCompanion.value.isEating = true
        _pandaCompanion.value.heartsRemaining += 3
        audio.playPandaSnack()
        showToast("You fed the Panda bamboo! 🎋🐼")
    }

    private fun updateRaycast() {
        val player = _playerState.value
        val camPos = player.getCameraPosition()
        val look = player.getCameraLookVector()
        val hit = _voxelWorld.value.raycast(camPos, look, 7.5f)
        _playerState.value = player.copy(targetRaycast = hit)
    }

    private fun updatePhysics(delta: Float) {
        val player = _playerState.value
        if (!player.isFlying) {
            // Apply gravity down to floor
            val world = _voxelWorld.value
            val bx = player.position.x.toInt()
            val bz = player.position.z.toInt()

            var groundY = 1f
            for (y in (world.sizeY - 1) downTo 0) {
                val b = world.getBlock(bx, y, bz)
                if (b != BlockType.AIR && b != BlockType.CRYSTAL_WATER) {
                    groundY = (y + 1).toFloat()
                    break
                }
            }

            if (player.position.y > groundY + 0.1f) {
                val newY = (player.position.y - 7.5f * delta).coerceAtLeast(groundY)
                _playerState.value = player.copy(position = Vector3(player.position.x, newY, player.position.z))
            }
        }
    }

    private fun showToast(msg: String) {
        viewModelScope.launch {
            _gameToast.value = msg
            delay(2200)
            if (_gameToast.value == msg) {
                _gameToast.value = null
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        audio.release()
    }
}
