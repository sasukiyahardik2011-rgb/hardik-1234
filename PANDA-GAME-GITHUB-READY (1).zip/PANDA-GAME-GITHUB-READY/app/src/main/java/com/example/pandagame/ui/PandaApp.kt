package com.example.pandagame.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.PandaGameTheme

@Composable
fun PandaApp(
    viewModel: GameViewModel = viewModel()
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val voxelWorld by viewModel.voxelWorld.collectAsState()
    val playerState by viewModel.playerState.collectAsState()
    val pandaCompanion by viewModel.pandaCompanion.collectAsState()
    val timeOfDay by viewModel.timeOfDay.collectAsState()
    val savedWorlds by viewModel.savedWorlds.collectAsState()
    val loadingProgress by viewModel.loadingProgress.collectAsState()
    val loadingMessage by viewModel.loadingMessage.collectAsState()
    val isPaused by viewModel.isPaused.collectAsState()
    val isInventoryOpen by viewModel.isInventoryOpen.collectAsState()
    val gameToast by viewModel.gameToast.collectAsState()
    val sensitivity by viewModel.lookSensitivity.collectAsState()
    val renderDistance by viewModel.renderDistance.collectAsState()
    val isDayNightEnabled by viewModel.isDayNightCycleEnabled.collectAsState()

    var showNewWorldDialog by remember { mutableStateOf(false) }

    // Android Hardware Back button handling
    BackHandler(enabled = true) {
        when {
            isInventoryOpen -> viewModel.toggleInventory()
            isPaused -> viewModel.resumeGame()
            showNewWorldDialog -> showNewWorldDialog = false
            currentScreen == GameScreen.IN_GAME -> viewModel.pauseGame()
            currentScreen == GameScreen.SAVED_WORLDS ||
            currentScreen == GameScreen.GUIDE ||
            currentScreen == GameScreen.SETTINGS -> viewModel.navigateTo(GameScreen.MAIN_MENU)
            currentScreen == GameScreen.MAIN_MENU -> viewModel.navigateTo(GameScreen.TITLE_SPLASH)
        }
    }

    PandaGameTheme(darkTheme = true) {
        Box(modifier = Modifier.fillMaxSize()) {
            Crossfade(targetState = currentScreen, label = "screen_transition") { screen ->
                when (screen) {
                    GameScreen.TITLE_SPLASH -> {
                        TitleSplashScreen(
                            onStartGame = {
                                if (savedWorlds.isNotEmpty()) {
                                    viewModel.loadSavedWorld(savedWorlds.first())
                                } else {
                                    viewModel.startNewGame("Panda Bamboo Valley", "Bamboo Forest")
                                }
                            },
                            onOpenMainMenu = { viewModel.navigateTo(GameScreen.MAIN_MENU) },
                            onOpenSaves = { viewModel.navigateTo(GameScreen.SAVED_WORLDS) }
                        )
                    }

                    GameScreen.MAIN_MENU -> {
                        MainMenuScreen(
                            onPlayDefault = {
                                if (savedWorlds.isNotEmpty()) {
                                    viewModel.loadSavedWorld(savedWorlds.first())
                                } else {
                                    viewModel.startNewGame("Panda Bamboo Valley", "Bamboo Forest")
                                }
                            },
                            onCreateNewWorld = { showNewWorldDialog = true },
                            onOpenSaves = { viewModel.navigateTo(GameScreen.SAVED_WORLDS) },
                            onOpenGuide = { viewModel.navigateTo(GameScreen.GUIDE) },
                            onOpenSettings = { viewModel.navigateTo(GameScreen.SETTINGS) },
                            onBackToTitle = { viewModel.navigateTo(GameScreen.TITLE_SPLASH) }
                        )
                    }

                    GameScreen.LOADING -> {
                        LoadingScreen(
                            message = loadingMessage,
                            progress = loadingProgress
                        )
                    }

                    GameScreen.IN_GAME -> {
                        InGameScreen(
                            world = voxelWorld,
                            playerState = playerState,
                            panda = pandaCompanion,
                            timeOfDay = timeOfDay,
                            renderDistance = renderDistance,
                            gameToast = gameToast,
                            onMove = { mx, mz -> viewModel.movePlayer(mx, mz) },
                            onLook = { dyaw, dpitch -> viewModel.rotateCamera(dyaw, dpitch) },
                            onJump = { viewModel.jumpOrFlyUp() },
                            onFlyDown = { viewModel.flyDown() },
                            onBreakBlock = { viewModel.breakTargetBlock() },
                            onPlaceBlock = { viewModel.placeBlock() },
                            onTogglePOV = { viewModel.togglePOV() },
                            onToggleFlight = { viewModel.toggleFlight() },
                            onToggleTime = { viewModel.toggleTimeOfDay() },
                            onFeedPanda = { viewModel.feedPanda() },
                            onPause = { viewModel.pauseGame() },
                            onSelectBlock = { block -> viewModel.selectHotbarSlot(block) },
                            onOpenInventory = { viewModel.toggleInventory() }
                        )
                    }

                    GameScreen.SAVED_WORLDS -> {
                        SaveGameScreen(
                            savedWorlds = savedWorlds,
                            onLoadWorld = { saved -> viewModel.loadSavedWorld(saved) },
                            onDeleteWorld = { saved -> viewModel.deleteSavedWorld(saved) },
                            onCreateNewWorld = { showNewWorldDialog = true },
                            onBack = { viewModel.navigateTo(GameScreen.MAIN_MENU) }
                        )
                    }

                    GameScreen.GUIDE -> {
                        PandaGuideScreen(
                            onBack = { viewModel.navigateTo(GameScreen.MAIN_MENU) }
                        )
                    }

                    GameScreen.SETTINGS -> {
                        PandaSettingsScreen(
                            sensitivity = sensitivity,
                            onSensitivityChange = { viewModel.lookSensitivity.value = it },
                            renderDistance = renderDistance,
                            onRenderDistanceChange = { viewModel.renderDistance.value = it },
                            isDayNightEnabled = isDayNightEnabled,
                            onDayNightToggle = { viewModel.isDayNightCycleEnabled.value = it },
                            onBack = { viewModel.navigateTo(GameScreen.MAIN_MENU) }
                        )
                    }

                    else -> {}
                }
            }

            // Dialogs on top of screens
            if (isPaused && currentScreen == GameScreen.IN_GAME) {
                PauseMenuDialog(
                    world = voxelWorld,
                    playerState = playerState,
                    sensitivity = sensitivity,
                    onSensitivityChange = { viewModel.lookSensitivity.value = it },
                    onResume = { viewModel.resumeGame() },
                    onSaveWorld = { viewModel.saveCurrentWorld() },
                    onToggleFlight = { viewModel.toggleFlight() },
                    onTogglePOV = { viewModel.togglePOV() },
                    onOpenSaves = {
                        viewModel.resumeGame()
                        viewModel.navigateTo(GameScreen.SAVED_WORLDS)
                    },
                    onExitToMenu = {
                        viewModel.saveCurrentWorld()
                        viewModel.resumeGame()
                        viewModel.navigateTo(GameScreen.MAIN_MENU)
                    }
                )
            }

            if (isInventoryOpen && currentScreen == GameScreen.IN_GAME) {
                PandaInventoryDialog(
                    selectedBlock = playerState.selectedBlock,
                    onSelectBlock = { block -> viewModel.selectHotbarSlot(block) },
                    onDismiss = { viewModel.toggleInventory() }
                )
            }

            if (showNewWorldDialog) {
                NewWorldDialog(
                    onDismiss = { showNewWorldDialog = false },
                    onCreateWorld = { name, biome, seed ->
                        showNewWorldDialog = false
                        viewModel.startNewGame(name, biome, seed)
                    }
                )
            }
        }
    }
}
