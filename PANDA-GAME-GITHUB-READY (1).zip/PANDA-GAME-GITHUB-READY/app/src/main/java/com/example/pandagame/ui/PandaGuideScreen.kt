package com.example.pandagame.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GeoAccentLight
import com.example.ui.theme.GeoAccentSoft
import com.example.ui.theme.GeoBackground
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryDark
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoSurfaceSubtle
import com.example.ui.theme.PandaLanternAmber
import com.example.ui.theme.PandaSakuraPink

@Composable
fun PandaGuideScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(GeoBackground)
            .testTag("panda_guide_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White)
                        .border(2.dp, GeoPrimaryDark, RoundedCornerShape(14.dp))
                        .testTag("guide_back_btn")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GeoPrimaryDark)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "PANDA GAME",
                        color = GeoPrimaryDark,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "HANDBOOK & SANDBOX GUIDE",
                        color = GeoPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )
                }

                Spacer(modifier = Modifier.size(42.dp))
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Guide Cards
            GuideSection(
                icon = "🎮",
                title = "1. Movement & Camera Controls",
                color = GeoPrimary,
                content = "• D-Pad (Left): Walk forward, back, or strafe.\n• Drag Right Screen: Smoothly rotate your 3D view.\n• UP / JUMP: Hop up voxels or fly upwards.\n• Flight Toggle: Switch between Walking gravity mode & Creative Free Flight!"
            )

            Spacer(modifier = Modifier.height(12.dp))

            GuideSection(
                icon = "🧱",
                title = "2. 3D Block Building & Breaking",
                color = GeoPrimaryDark,
                content = "• Crosshair Target: Aim at any voxel block within 7.5 blocks.\n• BUILD Button: Place the currently selected block on the targeted face.\n• BREAK Button: Remove the targeted block.\n• Hotbar & Bag 🎒: Select from 18 cute original voxel blocks!"
            )

            Spacer(modifier = Modifier.height(12.dp))

            GuideSection(
                icon = "🐼",
                title = "3. Cute Panda Companion & POV",
                color = PandaLanternAmber,
                content = "• Panda Companion: A cute 3D blocky panda cub roams the world with you.\n• Feed Bamboo 🎋: Tap the center bamboo button to feed your panda yummy treats!\n• 3rd Person POV 🐾: Toggle between First-Person and Cute Panda 3rd-Person mode anytime."
            )

            Spacer(modifier = Modifier.height(12.dp))

            GuideSection(
                icon = "💾",
                title = "4. Saving & Offline Worlds",
                color = GeoPrimary,
                content = "• All PANDA GAME worlds are stored 100% offline in your local database.\n• Open the Pause Menu anytime to save your progress, create multiple worlds, or explore different procedural seeds."
            )
        }
    }
}

@Composable
private fun GuideSection(
    icon: String,
    title: String,
    color: Color,
    content: String
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        color = GeoSurface,
        border = androidx.compose.foundation.BorderStroke(2.dp, GeoPrimaryDark),
        shadowElevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = icon, fontSize = 22.sp, modifier = Modifier.padding(end = 10.dp))
                Text(text = title, color = color, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = content,
                color = GeoPrimaryDark.copy(alpha = 0.85f),
                fontSize = 13.sp,
                lineHeight = 19.sp
            )
        }
    }
}
