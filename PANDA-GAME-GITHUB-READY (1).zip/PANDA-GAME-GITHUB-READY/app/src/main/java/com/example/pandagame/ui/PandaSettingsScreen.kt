package com.example.pandagame.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GeoAccentLight
import com.example.ui.theme.GeoAccentSoft
import com.example.ui.theme.GeoBackground
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryDark
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoSurfaceSubtle
import com.example.ui.theme.PandaLanternAmber

@Composable
fun PandaSettingsScreen(
    sensitivity: Float,
    onSensitivityChange: (Float) -> Unit,
    renderDistance: Int,
    onRenderDistanceChange: (Int) -> Unit,
    isDayNightEnabled: Boolean,
    onDayNightToggle: (Boolean) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(GeoBackground)
            .testTag("panda_settings_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White)
                        .border(2.dp, GeoPrimaryDark, RoundedCornerShape(14.dp))
                        .testTag("settings_back_btn")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GeoPrimaryDark)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "PANDA GAME",
                        color = GeoPrimaryDark,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "SANDBOX SETTINGS",
                        color = GeoPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )
                }

                Spacer(modifier = Modifier.size(42.dp))
            }

            Spacer(modifier = Modifier.height(20.dp))

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                color = GeoSurface,
                border = androidx.compose.foundation.BorderStroke(2.dp, GeoPrimaryDark),
                shadowElevation = 4.dp
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    // Sensitivity
                    Text(text = "Look Sensitivity: ${(sensitivity * 100).toInt()}%", color = GeoPrimaryDark, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Slider(
                        value = sensitivity,
                        onValueChange = onSensitivityChange,
                        valueRange = 0.1f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = GeoPrimaryDark,
                            activeTrackColor = GeoPrimary,
                            inactiveTrackColor = GeoAccentLight
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Render Distance
                    Text(text = "Voxel Render Distance: $renderDistance Chunks", color = GeoPrimaryDark, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Slider(
                        value = renderDistance.toFloat(),
                        onValueChange = { onRenderDistanceChange(it.toInt()) },
                        valueRange = 8f..16f,
                        steps = 7,
                        colors = SliderDefaults.colors(
                            thumbColor = GeoPrimaryDark,
                            activeTrackColor = GeoPrimary,
                            inactiveTrackColor = GeoAccentLight
                        )
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Day/Night Cycle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Dynamic Day/Night Cycle", color = GeoPrimaryDark, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text(text = "Sun, sunset, and starry skies", color = GeoPrimaryDark.copy(alpha = 0.7f), fontSize = 12.sp)
                        }
                        Switch(
                            checked = isDayNightEnabled,
                            onCheckedChange = onDayNightToggle,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = GeoPrimary
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                color = GeoSurface,
                border = androidx.compose.foundation.BorderStroke(2.dp, GeoPrimaryDark),
                shadowElevation = 4.dp
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(text = "About PANDA GAME", color = GeoPrimaryDark, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "PANDA GAME is an offline 3D voxel block sandbox game featuring geometric balance styling, serene bamboo biomes, cute original blocky voxel companions, and creative building.",
                        color = GeoPrimaryDark.copy(alpha = 0.85f),
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            }
        }
    }
}
