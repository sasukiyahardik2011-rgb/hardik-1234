package com.example.pandagame.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pandagame.data.GameSavedWorld
import com.example.ui.theme.GeoAccentLight
import com.example.ui.theme.GeoAccentSoft
import com.example.ui.theme.GeoBackground
import com.example.ui.theme.GeoPrimary
import com.example.ui.theme.GeoPrimaryDark
import com.example.ui.theme.GeoSurface
import com.example.ui.theme.GeoSurfaceSubtle
import com.example.ui.theme.PandaLanternAmber
import com.example.ui.theme.PandaSakuraPink
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SaveGameScreen(
    savedWorlds: List<GameSavedWorld>,
    onLoadWorld: (GameSavedWorld) -> Unit,
    onDeleteWorld: (GameSavedWorld) -> Unit,
    onCreateNewWorld: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val dateFormat = SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.getDefault())

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(GeoBackground)
            .testTag("save_game_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White)
                        .border(2.dp, GeoPrimaryDark, RoundedCornerShape(14.dp))
                        .testTag("saves_back_button")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = GeoPrimaryDark)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "PANDA GAME",
                        color = GeoPrimaryDark,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "SAVED WORLDS & ARCHIVES",
                        color = GeoPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )
                }

                IconButton(
                    onClick = onCreateNewWorld,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(GeoPrimary)
                        .border(2.dp, GeoPrimaryDark, RoundedCornerShape(14.dp))
                        .testTag("saves_create_new_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "New World", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Subtitle info pill
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = GeoAccentLight,
                border = androidx.compose.foundation.BorderStroke(1.5.dp, GeoAccentSoft)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "💾", fontSize = 20.sp, modifier = Modifier.padding(end = 10.dp))
                    Text(
                        text = "PANDA GAME stores your 3D voxel builds locally so you can play offline anytime!",
                        color = GeoPrimaryDark,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Saves List
            if (savedWorlds.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        shape = RoundedCornerShape(26.dp),
                        color = GeoSurface,
                        border = androidx.compose.foundation.BorderStroke(2.5.dp, GeoPrimaryDark),
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Text(text = "🎋", fontSize = 48.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "No Saved Worlds Yet",
                                color = GeoPrimaryDark,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            PandaActionButton(
                                text = "Create First Voxel World",
                                icon = Icons.Default.Add,
                                onClick = onCreateNewWorld,
                                containerColor = GeoPrimary,
                                contentColor = Color.White,
                                cornerRadius = 24,
                                testTag = "create_first_world_button"
                            )
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(savedWorlds, key = { it.id }) { saved ->
                        SavedWorldCard(
                            world = saved,
                            dateStr = dateFormat.format(Date(saved.lastPlayedTime)),
                            onLoad = { onLoadWorld(saved) },
                            onDelete = { onDeleteWorld(saved) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SavedWorldCard(
    world: GameSavedWorld,
    dateStr: String,
    onLoad: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onLoad() }
            .testTag("saved_world_card_${world.id}"),
        shape = RoundedCornerShape(22.dp),
        color = GeoSurface,
        border = androidx.compose.foundation.BorderStroke(2.dp, GeoPrimaryDark),
        shadowElevation = 6.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                when (world.biomeName) {
                                    "Sakura Valley" -> PandaSakuraPink
                                    "Panda Sanctuary" -> PandaLanternAmber
                                    else -> GeoPrimary
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = when (world.biomeName) {
                                "Sakura Valley" -> "🌸"
                                "Panda Sanctuary" -> "🏯"
                                "Zen Flatlands" -> "✨"
                                else -> "🎋"
                            },
                            fontSize = 22.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = world.name,
                            color = GeoPrimaryDark,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "PANDA GAME • ${world.biomeName}",
                            color = GeoPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFFFEBEE))
                        .border(1.dp, Color(0xFFFFCDD2), RoundedCornerShape(10.dp))
                        .testTag("delete_world_button_${world.id}")
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete World", tint = Color(0xFFC62828), modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Metadata info row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Blocks: ${world.blockCount} (Mod: +${world.modifiedBlockCount})",
                    color = GeoPrimaryDark.copy(alpha = 0.7f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = dateStr,
                    color = GeoPrimaryDark.copy(alpha = 0.6f),
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            PandaActionButton(
                text = "Load World in PANDA GAME",
                icon = Icons.Default.PlayArrow,
                onClick = onLoad,
                containerColor = GeoPrimary,
                contentColor = Color.White,
                cornerRadius = 20,
                modifier = Modifier.height(44.dp),
                testTag = "load_world_btn_${world.id}"
            )
        }
    }
}
