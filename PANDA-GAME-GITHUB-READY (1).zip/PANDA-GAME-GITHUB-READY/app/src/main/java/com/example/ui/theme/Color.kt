package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Geometric Balance Theme Palette (PANDA GAME)
val GeoBackground = Color(0xFFF1F8E9)       // Light Bamboo Lime Canvas
val GeoPrimary = Color(0xFF2E7D32)          // Emerald Bamboo Action
val GeoPrimaryDark = Color(0xFF1B5E20)      // Deep Forest Green
val GeoSecondary = Color(0xFF81C784)        // Mint Sage Accent
val GeoAccentLight = Color(0xFFC8E6C9)      // Pale Bamboo Green
val GeoAccentMid = Color(0xFF81C784)        // Mid Bamboo Green
val GeoAccentSoft = Color(0xFFA5D6A7)       // Soft Leaf Green
val GeoSurface = Color(0xFFFFFFFF)          // Crisp Card White
val GeoSurfaceSubtle = Color(0xFFE8F5E9)    // Subtle Bamboo Surface
val GeoSurfaceBorder = Color(0xFFA5D6A7)    // Clean Geometric Border

// Panda Game Brand Colors
val PandaEmerald = Color(0xFF2E7D32)
val PandaMint = Color(0xFF81C784)
val PandaSoftGreen = Color(0xFFA5D6A7)
val PandaBambooLight = Color(0xFFC8E6C9)
val PandaDarkForest = Color(0xFF1B5E20)

val PandaBlack = Color(0xFF1A1D1A)
val PandaDarkSlate = Color(0xFF1E281F)
val PandaPureWhite = Color(0xFFFFFFFF)
val PandaWarmWhite = Color(0xFFF9FBF8)

val PandaSakuraPink = Color(0xFFFF80AB)
val PandaSakuraLight = Color(0xFFFCE4EC)
val PandaLanternAmber = Color(0xFFFFB300)
val PandaLanternGlow = Color(0xFFFFD54F)

val PandaZenBlue = Color(0xFF4FC3F7)
val PandaNightSky = Color(0xFF0F1A24)
val PandaSunsetOrange = Color(0xFFFF7043)
