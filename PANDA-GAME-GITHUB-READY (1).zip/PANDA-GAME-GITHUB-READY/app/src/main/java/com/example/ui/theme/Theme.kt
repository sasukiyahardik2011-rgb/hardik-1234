package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val PandaDarkColorScheme = darkColorScheme(
    primary = GeoSecondary,
    onPrimary = GeoPrimaryDark,
    primaryContainer = GeoPrimaryDark,
    onPrimaryContainer = GeoAccentLight,
    secondary = GeoAccentLight,
    onSecondary = GeoPrimaryDark,
    secondaryContainer = Color(0xFF233026),
    onSecondaryContainer = GeoAccentLight,
    tertiary = PandaLanternAmber,
    onTertiary = PandaBlack,
    background = Color(0xFF131914),
    onBackground = PandaWarmWhite,
    surface = Color(0xFF1C251E),
    onSurface = PandaWarmWhite,
    surfaceVariant = Color(0xFF28362B),
    onSurfaceVariant = GeoAccentLight
)

private val PandaLightColorScheme = lightColorScheme(
    primary = GeoPrimary,
    onPrimary = Color.White,
    primaryContainer = GeoAccentLight,
    onPrimaryContainer = GeoPrimaryDark,
    secondary = GeoPrimaryDark,
    onSecondary = Color.White,
    secondaryContainer = GeoSurfaceSubtle,
    onSecondaryContainer = GeoPrimaryDark,
    tertiary = PandaLanternAmber,
    onTertiary = PandaBlack,
    background = GeoBackground,
    onBackground = GeoPrimaryDark,
    surface = GeoSurface,
    onSurface = GeoPrimaryDark,
    surfaceVariant = GeoSurfaceSubtle,
    onSurfaceVariant = GeoPrimaryDark
)

@Composable
fun PandaGameTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) PandaDarkColorScheme else PandaLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
